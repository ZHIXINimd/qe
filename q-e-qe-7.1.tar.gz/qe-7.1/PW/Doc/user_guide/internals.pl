# LaTeX2HTML 2019.2 (Released June 5, 2019)
# Associate internals original text with physical files.


$key = q/SubSec:badpara/;
$ref_files{$key} = "$dir".q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/pw2casino_info/;
$ref_files{$key} = "$dir".q|node12.html|; 
$noresave{$key} = "$nosave";

1;

