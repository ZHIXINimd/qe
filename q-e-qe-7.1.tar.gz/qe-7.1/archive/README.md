This folder is only intended for keeping temporary downloaded files needed by install_utils and specific plugins. See [here](https://gitlab.com/QEF/q-e/-/issues/467) for more details.
