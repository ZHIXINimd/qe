# deviceXlib

Library wrapping device-oriented routines and utilities