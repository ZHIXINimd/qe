#include <stdlib.h> 
size_t  c_cast_ptr (void * p ) {
   return (size_t) p  ;  }
