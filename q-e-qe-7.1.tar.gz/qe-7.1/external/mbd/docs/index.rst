Welcome to Pymbd
================

Only incomplete API reference is available at the moment.

For installation, see the Readme_. For examples, see the Readme_ or the `tests <https://github.com/jhrmnn/libmbd/blob/master/pymbd/test_pymbd.py>`_.

.. _Readme: https://github.com/jhrmnn/libmbd/blob/master/README.md

API reference
-------------

.. toctree::
    :maxdepth: 2

    api
